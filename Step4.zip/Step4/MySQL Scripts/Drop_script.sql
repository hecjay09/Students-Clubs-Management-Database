-- MySQL Version of scripts for dropping tables
USE Project_Gr8_Student_Club;

DROP TABLE Alumnus_WorkHistory;
DROP TABLE Member_WorksOn_Project;
DROP TABLE Member_Joins_Group;
DROP TABLE Project;
DROP TABLE Event;
DROP TABLE Club_Group;
DROP TABLE Club;
DROP TABLE Member;
